// Smooth anchor scrolling is handled via CSS (scroll-behavior: smooth).
// Metronome 5:5 — circle expands on inhale and contracts on exhale, smoothly.

(function(){
  const circle = document.getElementById('breathCircle');
  const label = document.getElementById('phaseLabel');
  const toggleBtn = document.getElementById('toggleBtn');
  const yearEl = document.getElementById('year');
  if (yearEl) yearEl.textContent = new Date().getFullYear();

  const D_INHALE = 5000; // ms
  const D_EXHALE = 5000; // ms
  const MIN_SCALE = 0.68;
  const MAX_SCALE = 1.0;

  let running = false;
  let phase = 'inhale'; // 'inhale' | 'exhale'
  let phaseStart = 0;
  let rafId = null;

  function easeInOut(t){
    // Smooth cosine ease
    return 0.5 * (1 - Math.cos(Math.PI * t));
  }

  function setPhase(next){
    phase = next;
    phaseStart = performance.now();
    if (label){
      label.textContent = (phase === 'inhale') ? 'Вдох' : 'Выдох';
    }
  }

  function frame(now){
    const dur = (phase === 'inhale') ? D_INHALE : D_EXHALE;
    const t = Math.min((now - phaseStart) / dur, 1);
    const e = easeInOut(t);
    const scale = (phase === 'inhale')
      ? (MIN_SCALE + (MAX_SCALE - MIN_SCALE) * e)
      : (MAX_SCALE - (MAX_SCALE - MIN_SCALE) * e);

    circle.style.transform = `scale(${scale.toFixed(4)})`;

    if (t >= 1){
      setPhase(phase === 'inhale' ? 'exhale' : 'inhale');
    }
    if (running) rafId = requestAnimationFrame(frame);
  }

  function start(){
    if (running) return;
    running = true;
    toggleBtn.textContent = 'Пауза';
    setPhase('inhale');
    rafId = requestAnimationFrame(frame);
  }

  function pause(){
    running = false;
    toggleBtn.textContent = 'Старт';
    if (rafId) cancelAnimationFrame(rafId);
    label.textContent = 'Пауза';
  }

  toggleBtn.addEventListener('click', ()=>{
    running ? pause() : start();
  });

  // Space toggles start/pause for convenience
  window.addEventListener('keydown', (e)=>{
    if (e.code === 'Space'){
      e.preventDefault();
      running ? pause() : start();
    }
  });
})();